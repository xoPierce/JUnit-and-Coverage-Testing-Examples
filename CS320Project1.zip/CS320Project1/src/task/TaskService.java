package task;
import java.util.ArrayList;

public class TaskService {
	// Instance Fields
	private ArrayList<Task> taskList;
	
	// Constructor
	public TaskService() {
		taskList = new ArrayList<Task>();
	}
		
	// Accessor
	public ArrayList<Task> getTaskList() {
		return taskList;
	}
	
	// Method to add a task to the task list with a unique ID
	public boolean addTask(String ID, String name, String description) {
		Task task = search(ID);
		if (task == null) {
			Task newTask = new Task(ID, name, description);
			taskList.add(newTask);
			return true;
		}
		return false;
	}
	
	// Method to delete a task from the task list with a unique ID
	public void deleteTask(String taskID) {
		Task task = search(taskID);
		if (task != null) {
			taskList.remove(task);
		}
		else {
			throw new IllegalArgumentException("Cannot delete task.");
		}
	}
	
	// Searches through the task list with a task ID
	public Task search(String taskID) {
		Task searched_task = null;
		for (Task task: taskList) {
			if (task.getTaskID().equals(taskID)) {
				return task;
			}
		}
		return searched_task;
	}
	
	// Method to update the name field
	public void updateName(String taskID, String newName) {
		Task task = search(taskID);
		if (task != null) {
			task.setName(newName);
		}
		else {
			throw new IllegalArgumentException("Cannot update name.");
		}
	}
	
	// Method to update the description field
	public void updateDescription(String taskID, String description) {
		Task task = search(taskID);
		if (task != null) {
			task.setDescription(description);
		}
		else {
			throw new IllegalArgumentException("Cannot update name.");
		}
	}
}
