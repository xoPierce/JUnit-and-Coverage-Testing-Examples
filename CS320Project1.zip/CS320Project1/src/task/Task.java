package task;

public class Task {

	// Instance Fields
	private String taskID;
	private String name;
	private String description;
	
	// Constructor
	public Task(String taskID, String name, String description) {
		// Task ID cannot be null or longer than 10 characters
		if (taskID == null || taskID.length() > 10) {
			throw new IllegalArgumentException("Invalid Task ID");
		}
		// Task name cannot be null or longer than 20 characters
		if (name == null || name.length() > 20) {
			throw new IllegalArgumentException("Invalid Name");
		}
		// Task description cannot be null or longer than 50 characters
		if (description == null || description.length() > 50) {
			throw new IllegalArgumentException("Invalid Description");
		}
		
		this.taskID = taskID;
		this.name = name;
		this.description = description;
	}
	
	// Mutators
	public void setName(String name) {
		// Name cannot be null or longer than 20 characters
		if (name == null || name.length() > 20) {
			throw new IllegalArgumentException("Invalid Name");
		}	
		this.name = name;
	}
	
	public void setDescription(String description) {
		// Task name cannot be null or longer than 20 characters
		if (description == null || description.length() > 50) {
			throw new IllegalArgumentException("Invalid Description");
		}
		this.description = description;
	}
	
	// Accessors
	public String getTaskID() {
		return taskID;
	}
	public String getName() {
		return name;
	}
	public String getDescription() {
		return description;
	}
}
