package task;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class TaskServiceTest {

	@Test
	void testTaskServiceObject() {
		TaskService taskService = new TaskService();
		assertTrue(taskService.getTaskList().isEmpty() == true);
	}
	
	@Test
	void testTaskServiceAddTask() {
		TaskService taskService = new TaskService();
		assertTrue(taskService.addTask("1", "name", "description"));
	}
	
	@Test
	void testTaskServiceAddTaskWithInvalidID() {
		TaskService taskService = new TaskService();
		taskService.addTask("1", "name", "description");
		assertFalse(taskService.addTask("1", "name", "description"));
	}
	
	@Test
	void testTaskServiceDeleteTask() {
		TaskService taskService = new TaskService();
		taskService.addTask("1", "name", "description");
		assertTrue(taskService.search("1").getTaskID().equals("1"));
		assertTrue(taskService.search("1").getName().equals("name"));
		assertTrue(taskService.search("1").getDescription().equals("description"));
		taskService.deleteTask("1");
		assertTrue(taskService.search("1") == null);
	}
	
	@Test
	void testTaskServiceDeleteTaskWithInvalidID() {
		TaskService taskService = new TaskService();
		Assertions.assertThrows(IllegalArgumentException.class, ()-> { 
			taskService.deleteTask("3");
		});
	}
	
	@Test 
	void testTaskServiceUpdateName() {
		TaskService taskService = new TaskService();
		taskService.addTask("1", "name", "description");
		assertTrue(taskService.search("1").getTaskID().equals("1"));
		assertTrue(taskService.search("1").getName().equals("name"));
		assertTrue(taskService.search("1").getDescription().equals("description"));
		taskService.updateName("1", "cool name");
		assertTrue(taskService.search("1").getTaskID().equals("1"));
		assertTrue(taskService.search("1").getName().equals("cool name"));
		assertTrue(taskService.search("1").getDescription().equals("description"));
	}
	
	@Test
	void testTaskServiceUpdateNameWithInvalidID() {
		TaskService taskService = new TaskService();
		Assertions.assertThrows(IllegalArgumentException.class, ()-> { 
			taskService.updateName("3", "new name");
		});
	}
	
	@Test 
	void testTaskServiceUpdateDescription() {
		TaskService taskService = new TaskService();
		taskService.addTask("1", "name", "description");
		assertTrue(taskService.search("1").getName().equals("name"));
		assertTrue(taskService.search("1").getDescription().equals("description"));
		taskService.updateDescription("1", "really cool description");
		assertTrue(taskService.search("1").getName().equals("name"));
		assertTrue(taskService.search("1").getDescription().equals("really cool description"));
	}
	
	@Test
	void testTaskServiceUpdateDescriptionWithInvalidID() {
		TaskService taskService = new TaskService();
		Assertions.assertThrows(IllegalArgumentException.class, ()-> { 
			taskService.updateDescription("3", "new description");
		});
	}
}
