package task;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class TaskTest {

	@Test
	void testTaskObject() {
		Task task = new Task("0", "name", "description");
		assertTrue(task.getTaskID().equals("0"));
		assertTrue(task.getName().equals("name"));
		assertTrue(task.getDescription().equals("description"));
	}
	
	@Test
	void testTaskSetName() {
		Task task = new Task("0", "name", "description");
		task.setName("new_name");
		assertTrue(task.getName().equals("new_name"));
	}
	
	@Test
	void testTaskSetNameTooLong() {
		Task task = new Task("0", "name", "description");
		Assertions.assertThrows(IllegalArgumentException.class, ()-> { 
			task.setName("Name is really really really really long");
		});
	}
	
	@Test
	void testTaskSetNameNull() {
		Task task = new Task("0", "name", "description");
		Assertions.assertThrows(IllegalArgumentException.class, ()-> { 
			task.setName(null);
		});
	}
	
	@Test
	void testTaskSetDescription() {
		Task task = new Task("0", "name", "description");
		task.setDescription("new_description");
		assertTrue(task.getDescription().equals("new_description"));
	}
	
	@Test
	void testTaskSetDescriptionTooLong() {
		Task task = new Task("0", "name", "description");
		Assertions.assertThrows(IllegalArgumentException.class, ()-> { 
			task.setDescription("Description is really really really really really really really long");
		});
	}
	
	@Test
	void testTaskSetDescriptionNull() {
		Task task = new Task("0", "name", "description");
		Assertions.assertThrows(IllegalArgumentException.class, ()-> { 
			task.setDescription(null);
		});
	}
	
	@Test
	void testTaskIDTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> { 
			new Task("01234567890", "name", "description");
		});
	}
	
	@Test
	void testTaskIDIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> { 
			new Task(null, "name", "description");
		});
	}
	
	@Test
	void testTaskNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> { 
			new Task("0", "nameisreallyreallyreallyreallylong", "description");
		});
	}
	
	@Test
	void testTaskNameIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> { 
			new Task(null, "name", "description");
		});
	}
	
	@Test
	void testTaskDescriptionTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> { 
			new Task("0", "name", "descriptionisreallyreallyreallyreallyreallyreallylong");
		});
	}
	
	@Test
	void testTaskDescriptionIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> { 
			new Task("0", "name", null);
		});
	}
}
