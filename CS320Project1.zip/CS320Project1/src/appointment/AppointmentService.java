package appointment;
import java.util.ArrayList;
import java.util.Date;

public class AppointmentService {
	// Instance Fields
	private ArrayList<Appointment> appointmentList;
	
	// Constructor
	public AppointmentService() {
		appointmentList = new ArrayList<Appointment>();
	}
	
	public ArrayList<Appointment> getAppointmentList() {
		return appointmentList;
	}
	
	// Method to add an appointment to the appointment list with a unique ID
	public boolean addAppointment(String ID, Date date, String description) {
		Appointment appointment = search(ID);
		if (appointment == null) {
			Appointment newAppointment = new Appointment(ID, date, description);
			appointmentList.add(newAppointment);
			return true;
		}
		return false;
	}
	
	// Method to delete an appointment from the appointment list with a unique ID
	public void deleteAppointment(String appointmentID) {
		Appointment appointment = search(appointmentID);
		if (appointment != null) {
			appointmentList.remove(appointment);
		}
		else {
			throw new IllegalArgumentException("Cannot delete appointment.");
		}
	}
	
	// Searches through the task list with a task ID
	public Appointment search(String appointmentID) {
		Appointment searched_appt = null;
		for (Appointment appointment: appointmentList) {
			if (appointment.getAppointmentID().equals(appointmentID)) {
				return appointment;
			}
		}
		return searched_appt;
	}
}
