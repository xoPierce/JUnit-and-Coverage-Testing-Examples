package appointment;

import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class AppointmentTest {

	@Test
	void testAppointmentObject() {
		Date date = new Date();
		date.setMonth(5);
		Appointment appointment = new Appointment("0", date, "description");
		assertTrue(appointment.getAppointmentID().equals("0"));
		assertTrue(appointment.getDate().equals(date));
		assertTrue(appointment.getDescription().equals("description"));
	}
	
	@Test
	void testAppointmentIDIsNull() {
		Date date = new Date();
		date.setMonth(5);
		Assertions.assertThrows(IllegalArgumentException.class, ()-> { 
			new Appointment(null, date, "description");
		});
	}
	
	@Test
	void testDateIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> { 
			new Appointment("0", null, "description");
		});
	}
	
	@Test
	void testDateIsInThePast() {
		Date date = new Date();
		date.setMonth(0);
		Assertions.assertThrows(IllegalArgumentException.class, ()-> { 
			new Appointment("0", date, "description");
		});
	}
	
	@Test
	void testAppointmentDescriptionIsNull() {
		Date date = new Date();
		date.setMonth(5);
		Assertions.assertThrows(IllegalArgumentException.class, ()-> { 
			new Appointment("0", date, null);
		});
	}
	
	@Test
	void testAppointmentDescriptionIsTooLong() {
		Date date = new Date();
		date.setMonth(5);
		Assertions.assertThrows(IllegalArgumentException.class, ()-> { 
			new Appointment("0", date, "Description is really really really really really really long!!!!!!!!!!!!");
		});
	}
}
