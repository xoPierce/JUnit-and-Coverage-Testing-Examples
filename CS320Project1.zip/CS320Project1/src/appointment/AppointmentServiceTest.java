package appointment;

import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class AppointmentServiceTest {

	@Test
	void testAppointmentServiceObject() {
		AppointmentService appointmentService = new AppointmentService();
		assertTrue(appointmentService.getAppointmentList().isEmpty() == true);
	}
	
	@Test
	void testAppointmentServiceAddAppointmentWithValidID() {
		AppointmentService appointmentService = new AppointmentService();
		Date date = new Date();
		date.setMonth(5);
		assertTrue(appointmentService.addAppointment("1", date, "description1"));
	}
	
	@Test
	void testAppointmentServiceAddAppointmentInvalidID() {
		AppointmentService appointmentService = new AppointmentService();
		Date date = new Date();
		date.setMonth(5);
		appointmentService.addAppointment("1", date, "description1");
		assertFalse(appointmentService.addAppointment("1", date, "description1"));
	}
	
	@Test
	void testAppointmentServiceDeleteAppointment() {
		AppointmentService appointmentService = new AppointmentService();
		Date date = new Date();
		date.setMonth(5);
		appointmentService.addAppointment("1", date, "description");
		assertTrue(appointmentService.search("1").getDate().equals(date));
		assertTrue(appointmentService.search("1").getDescription().equals("description"));
		appointmentService.deleteAppointment("1");
		assertTrue(appointmentService.search("1") == null);
	}
	
	@Test
	void testAppointmentServiceDeleteApptWithInvalidID() {
		AppointmentService appointmentService = new AppointmentService();
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			appointmentService.deleteAppointment("3");
		});
	}
}
