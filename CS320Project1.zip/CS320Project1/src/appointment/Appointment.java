package appointment;

import java.util.Date;

public class Appointment {

	// Instance Fields
	private String appointmentID;
	private Date date;
	private String description;
	
	// Constructor
	public Appointment(String appointmentID, Date date, String description) {
		// AppointmentID cannot be null or longer than 10 characters
		if (appointmentID == null || appointmentID.length() > 10) {
			throw new IllegalArgumentException("Invalid Appointment ID");
		}
		// Date cannot be a date in the past
		if (date == null || date.before(new Date()) == true) {
			throw new IllegalArgumentException("Invalid Date");
		}
		// Description cannot be null or longer than 50 characters
		if (description == null || description.length() > 50) {
			throw new IllegalArgumentException("Invalid Description");
		}
		this.appointmentID = appointmentID;
		this.date = date;
		this.description = description;
	}
	
	// Accessors
	public String getAppointmentID() {
		return appointmentID;
	}
	public Date getDate() {
		return date;
	}
	public String getDescription() {
		return description;
	}
}